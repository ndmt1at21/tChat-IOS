//
//  TSMomentsViewController.swift
//  TSWeChat
//
//  Created by Hilen on 8/17/16.
//  Copyright © 2016 Hilen. All rights reserved.
//

/// High performance

import UIKit

class TSMomentsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
