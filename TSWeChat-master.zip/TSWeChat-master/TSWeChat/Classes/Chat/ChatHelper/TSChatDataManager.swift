//
//  ChatDataManager.swift
//  TSWeChat
//
//  Created by Hilen on 3/1/16.
//  Copyright © 2016 Hilen. All rights reserved.
//

import Foundation

class ChatDataManager {
    
}