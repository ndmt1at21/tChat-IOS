//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


let arrayOfNumbers = [1, 2, 3, 4]
let arrayOfString = arrayOfNumbers.map { "\($0)" }